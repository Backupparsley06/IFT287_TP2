SELECT * FROM Client;
SELECT * FROM Chambre;
SELECT * FROM Commodite;
SELECT * FROM Reservation;
SELECT * FROM InclusionCommodite;