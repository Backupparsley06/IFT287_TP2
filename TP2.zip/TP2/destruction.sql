drop table IF EXISTS Reservation;
drop table IF EXISTS InclusionCommodite;
drop table IF EXISTS Client;
drop table IF EXISTS Chambre;
drop table IF EXISTS Commodite;